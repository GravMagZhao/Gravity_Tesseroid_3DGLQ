  This program titled ��Tesseroid_3D-Gauss-Legendre_Plus�� is a new version of ��Tesseroid_3D-Gauss-Legendre��, with adding the equivalence of kernel matrix.
  To run this Fortran program, you should firstly install the Visual Studio (a software development platform) and then the Intel Visual Fortran (a Fortran compiler). The versions of the two software should be matched well, otherwise it couldn��t compile in your computer. You can see more information and download the two software in their official websites:
www.visualstudio.com and https://software.intel.com/en-us/fortran-compilers
The platform and Fortran compiler can be installed in Windows, Linux or macOS systems of both 32-bit and 64-bit. Here this program is based on Windows 7 system (64bit).
  After installing the two software, we can click the ��Tesseroid_3D-Gauss-Legendre_Plus.sln��, and then you will turn into the program interface. The parameters we can adjust are on the ��Constant_set.f90�� and ��Main_Program.f90��.
  The most variates in our problem are noted. Here we list the common variates.
  obs_height=6421.0------------------------height of observation surface
  radmin=6271.0-----------------------------the minimum radius of the model
  radmax=6371.0-----------------------------the maximum radius of the model
  latmin=-90.0---------------------------------the minimum latitude of the model
  latmax=90.0---------------------------------the maximum latitude of the model
  lonmin=0.0----------------------------------the minimum longitude of the model
  lonmax=360.0------------------------------the maximum longitude of the model       
  nr=1-------------------------------------------the number of subdivision in radial direction
  nlat=180--------------------------------------the number of subdivision in latitudinal direction
  nlon=360-------------------------------------the number of subdivision in longitudinal direction

  Rad(nr),Lat(nlat),Lon(nlon)-------------------the arrays recording the subdivision information

  V(nlat,nlon),Gx(nlat,nlon),Gy(nlat,nlon),Gz(nlat,nlon),Gxx(nlat,nlon),Gxy(nlat,nlon),Gxz(nlat,nlon),Gyy(nlat,nlon),Gyz(nlat,nlon),Gzz(nlat,nlon)-----------------------the gravitational potential, accelerations and gradient tensors

  delta_r,delta_lat,delta_lon----------------------------the intervals of subdivision

  Gxx_kernel(nlat*nlon,nlat*nr)---------------------------the kernel matrix of Gxx (using equivalence of kernel matrix)
